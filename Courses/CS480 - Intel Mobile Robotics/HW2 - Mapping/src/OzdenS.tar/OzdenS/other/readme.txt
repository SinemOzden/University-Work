TO RUN THE CODE
roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=$(find OzdenS)/kinetic.world
roslaunch turtlebot_rviz_launchers view_navigation.launch
roslaunch turtlebot_gazebo gmapping_demo.launch
roslaunch OzdenS assign2.launch

TEAM MEMBERS
Selin Dinc
Sinem Ozden

YOUTUBE LINKS
https://youtu.be/xiwsQPun5Ys
https://youtu.be/cCTY0AvwDMQ

